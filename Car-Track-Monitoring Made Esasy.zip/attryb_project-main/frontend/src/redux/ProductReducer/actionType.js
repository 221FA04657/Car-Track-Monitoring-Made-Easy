export const CAR_REQUEST = "CAR_REQUEST" ;
export const CAR_FAILURE = "CAR_FAILURE" ;
export const GET_CAR_SUCCSESS = "GET_CAR_SUCCSESS";
export const DELETE_CAR_SUCCESS = "DELETE_CAR_SUCCESS";
export const EDIT_CAR_SUCCESS = "EDIT_CAR_SUCCESS";
// export const 
// export const 
// export const 